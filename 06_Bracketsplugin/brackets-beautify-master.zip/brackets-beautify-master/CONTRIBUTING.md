# Contributing

## Issues
Brackets Beautify uses [js-beautify](https://github.com/beautify-web/js-beautify) to beautify files and is therefore limited to its capabilities.

If you have any issue concerning the formatting, please test it on the website of the library first:
```
http://jsbeautifier.org/
```
If the issue persists, please refer to the [js-beautify issues](https://github.com/beautify-web/js-beautify/issues).
