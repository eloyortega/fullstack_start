var _                = brackets.getModule("thirdparty/lodash");

define('_', function() {
  return _;
})
